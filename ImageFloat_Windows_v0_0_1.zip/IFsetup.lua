-- handle functions for:
--		library names
--		general params
-- 		etc...

return {
	windowSize = {1280, 600},
	numThreads = 4,
	
	imageLoadType = "PPM", -- PPM / IM / RAW / FPM
	imageLoadParams = "",
	imageLoadName = "img.ppm",
	imageLoadPath = "",

	imageSaveType = "PPM", -- PPM / IM / FPM
	imageSaveParams = "",
	imageSaveName = "out.ppm",
	imageSavePath = "",

	--Paths
	threadPath = "Thread",
	libPath = "./lib/",
	imgPath = "./res/",
	ttfPath = "./res/",
	incPath = "./inc/",

	--library names
}
